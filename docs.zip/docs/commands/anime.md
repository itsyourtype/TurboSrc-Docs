---
description: 10 commands
---

# 🔞 Anime

### Reactions

- **Description**: anime reactions
- **Command Usage**: `!anime <reaction>`
- **Slash Usage**: `/anime`
- **Cooldown**: 5 seconds

|      |      |        |
| ---- | ---- | ------ |
| hug  | kiss | cuddle |
| feed | pat  | poke   |
| slap | smug | tickle |
| wink |      |        |
